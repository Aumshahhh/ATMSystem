package VirtualATM;
import java.util.Date;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.*;

public class Withdrawal extends JFrame implements ActionListener {
    JTextField amountField;
    JButton withdrawButton, backButton;
    String pin;

    Withdrawal(String pin) {
        this.pin = pin;

        ImageIcon icon = new ImageIcon(ClassLoader.getSystemResource("VirtualATM/icons/atm.jpg"));
        Image image = icon.getImage().getScaledInstance(1000, 1180, Image.SCALE_DEFAULT);
        ImageIcon scaledIcon = new ImageIcon(image);
        JLabel background = new JLabel(scaledIcon);
        background.setBounds(0, 0, 960, 1080);
        add(background);

        JLabel prompt = new JLabel("ENTER AMOUNT YOU WANT TO WITHDRAW");
        prompt.setForeground(Color.WHITE);
        prompt.setFont(new Font("System", Font.BOLD, 16));
        prompt.setBounds(190, 350, 400, 35);
        background.add(prompt);

        amountField = new JTextField();// text field to enter amount to be withdrawn
        amountField.setFont(new Font("Raleway", Font.BOLD, 22));
        amountField.setBounds(190, 420, 320, 25);
        background.add(amountField);

        withdrawButton = new JButton("WITHDRAW"); 
        withdrawButton.setBounds(390, 588, 150, 35);
        background.add(withdrawButton);

        backButton = new JButton("BACK");
        backButton.setBounds(390, 633, 150, 35);
        background.add(backButton);

        withdrawButton.addActionListener(this);
        backButton.addActionListener(this);

        setLayout(null);
        setSize(960, 1080);
        setUndecorated(true);
        setLocation(500, 0);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        try {
            String amountStr = amountField.getText();
            if (ae.getSource() == withdrawButton) {
                if (amountStr.equals("")) {
                    JOptionPane.showMessageDialog(null, "Please enter the amount you want to withdraw.");
                } else {
                    double amount = Double.parseDouble(amountStr);
                    Date date = new Date();

                    DBConnection conn = new DBConnection();
                    String cardQuery = "SELECT cardno FROM login WHERE pin = ?";// gets card number using pin
                    PreparedStatement cardStmt = conn.c.prepareStatement(cardQuery);
                    cardStmt.setString(1, pin);
                    ResultSet rs = cardStmt.executeQuery();

                    if (rs.next()) {
                        String cardNumber = rs.getString("cardno");

                        // Check account balance
                        String balanceQuery = "SELECT SUM(CASE WHEN type = 'Deposit' THEN amount ELSE -amount END) AS balance FROM transactions WHERE card_number = ?";
                        PreparedStatement balanceStmt = conn.c.prepareStatement(balanceQuery);
                        balanceStmt.setString(1, cardNumber);
                        ResultSet balanceRs = balanceStmt.executeQuery();
                        // insufficient balance
                        if (balanceRs.next()) {
                            double balance = balanceRs.getDouble("balance");
                            if (amount > balance) {
                                JOptionPane.showMessageDialog(null, "Insufficient balance.");
                                return;
                            }
                        }

                        String insertQuery = "INSERT INTO transactions (card_number, date, type, amount) VALUES (?, ?, ?, ?)";
                        PreparedStatement pstmt = conn.c.prepareStatement(insertQuery);
                        pstmt.setString(1, cardNumber);
                        pstmt.setTimestamp(2, new java.sql.Timestamp(date.getTime()));
                        pstmt.setString(3, "Withdrawal");
                        pstmt.setDouble(4, amount);
                        pstmt.executeUpdate();

                        JOptionPane.showMessageDialog(null, "$" + amount + " Withdrawn Successfully");
                        setVisible(false);
                        new TransactionPage(pin).setVisible(true);
                    } else {
                        JOptionPane.showMessageDialog(null, "Card number not found for this PIN.");
                    }
                }
            } else if (ae.getSource() == backButton) {
                setVisible(false);
                new TransactionPage(pin).setVisible(true);
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Transaction failed: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        new Withdrawal("").setVisible(true);
    }
}