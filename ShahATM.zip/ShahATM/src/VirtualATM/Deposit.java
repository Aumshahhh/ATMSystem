package VirtualATM;

import java.util.Date;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class Deposit extends JFrame implements ActionListener {

    JTextField t1;
    JButton b1, b2; // this is my back and deposit button
    JLabel l1;
    String pin;  // saves user's pin to refer to the user in the DB.

    Deposit(String pin) {
        this.pin = pin;

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("VirtualATM/icons/atm.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1000, 1180, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l3 = new JLabel(i3);
        l3.setBounds(0, 0, 960, 1080);
        add(l3);

        l1 = new JLabel("ENTER AMOUNT YOU WANT TO DEPOSIT");
        l1.setForeground(Color.WHITE);
        l1.setFont(new Font("System", Font.BOLD, 16));

        t1 = new JTextField();
        t1.setFont(new Font("Raleway", Font.BOLD, 22)); // input field for amount deposited

        b1 = new JButton("DEPOSIT");
        b2 = new JButton("BACK");

        setLayout(null);
        l1.setBounds(190, 350, 400, 35);
        l3.add(l1);

        t1.setBounds(190, 420, 320, 25);
        l3.add(t1);

        b1.setBounds(390, 588, 150, 35);
        l3.add(b1);

        b2.setBounds(390, 633, 150, 35);
        l3.add(b2);

        b1.addActionListener(this);
        b2.addActionListener(this);

        setSize(960, 1080);
        setUndecorated(true);
        setLocation(500, 0);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        try {
            String amount = t1.getText();
            Date date = new Date(); //timestamp

            if (ae.getSource() == b1) { // If user clicls deposit.
                if (amount.equals("")) {
                    JOptionPane.showMessageDialog(null, "Please enter the amount to deposit.");
                } else {
                    DBConnection c1 = new DBConnection();

                    
                    String cardQuery = "SELECT cardno FROM login WHERE pin = ?";
                    PreparedStatement cardStmt = c1.c.prepareStatement(cardQuery);
                    cardStmt.setString(1, pin);
                    ResultSet rs = cardStmt.executeQuery();

                    if (rs.next()) {
                        String cardNumber = rs.getString("cardno");
                        //https://www.w3schools.com/php/php_mysql_prepared_statements.asp
                        // puts the deposit into transactions table to record it. 
                        String query = "INSERT INTO transactions (card_number, date, type, amount) VALUES (?, ?, ?, ?)";
                        PreparedStatement pstmt = c1.c.prepareStatement(query);
                        pstmt.setString(1, cardNumber);
                        pstmt.setTimestamp(2, new java.sql.Timestamp(date.getTime()));
                        pstmt.setString(3, "Deposit");
                        pstmt.setDouble(4, Double.parseDouble(amount));
                        pstmt.executeUpdate();

                        JOptionPane.showMessageDialog(null, "$" + amount + " Deposited Successfully");//successful deposit
                        setVisible(false);
                        new TransactionPage(pin).setVisible(true);
                    } else {
                        JOptionPane.showMessageDialog(null, "Card number not found for this account.");//unsuccesful deposit
                    }
                }
            } else if (ae.getSource() == b2) {
                setVisible(false);
                new TransactionPage(pin).setVisible(true);
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Transaction failed: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        new Deposit("").setVisible(true); //test
    }
}


