package VirtualATM;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

// https://stackoverflow.com/questions/6344269/jframe-actionlistener
public class CheckBalance extends JFrame implements ActionListener {
    JLabel l1;
    JButton b1;
    String pin;

    CheckBalance(String pin) {
        this.pin = pin;
        // Got some help from Stack to upload background image: https://stackoverflow.com/questions/8433814/jlabel-as-background-image
        // Loads image of ATM background that I got from Freepik: https://img.freepik.com/free-vector/atm-screen-automated-teller-machine-monitor-illustration_1441-3923.jpg
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("VirtualATM/icons/atm.jpg")); 
        Image i2 = i1.getImage().getScaledInstance(1000, 1180, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel background = new JLabel(i3);
        background.setBounds(0, 0, 960, 1080);
        add(background);

        l1 = new JLabel();
        l1.setFont(new Font("System", Font.BOLD, 16));
        l1.setForeground(Color.WHITE);
        l1.setBounds(190, 350, 400, 35);
        background.add(l1);
        // Simple back button to go back to transactions page
        b1 = new JButton("BACK");
        b1.setBounds(390, 633, 150, 35);
        background.add(b1);

        b1.addActionListener(this);

        String balanceQuery = "SELECT SUM(CASE WHEN type = 'Deposit' THEN amount ELSE -amount END) AS balance FROM transactions WHERE card_number = ?";
        try {
            DBConnection c1 = new DBConnection();
            // This gets the card number from the database based on the pin that was entered. 
            String cardQuery = "SELECT cardno FROM login WHERE pin = ?";
            PreparedStatement cardStmt = c1.c.prepareStatement(cardQuery);
            cardStmt.setString(1, pin);
            ResultSet rs = cardStmt.executeQuery();

            if (rs.next()) {
                String cardNumber = rs.getString("cardno");
                PreparedStatement stmt = c1.c.prepareStatement(balanceQuery); // calculate current balance
                stmt.setString(1, cardNumber);
                ResultSet balanceRs = stmt.executeQuery();

                if (balanceRs.next()) {
                    double balance = balanceRs.getDouble("balance");
                    l1.setText("Your Current Account Balance is $" + balance); // displays balance on screen
                } else {
                    l1.setText("Unable to retrieve balance.");
                }
            } else {
                l1.setText("Card number not found for this account.");
            }
        } catch (Exception e) {
            l1.setText("Error retrieving balance: " + e.getMessage());
            e.printStackTrace();
        }

        setLayout(null);
        setSize(960, 1080); // ATM background picture size
        setUndecorated(true);
        setLocation(500, 0);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        setVisible(false);
        new TransactionPage(pin).setVisible(true); // takes us back to the transaction page
    }

    public static void main(String[] args) {
        new CheckBalance("").setVisible(true); //test
    }
}

