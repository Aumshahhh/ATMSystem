package VirtualATM;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.*;

public class Signup3 extends JFrame implements ActionListener{

    JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12;
    JRadioButton r1,r2,r3,r4;
    JButton b1,b2;
    JCheckBox c1,c2,c3,c4,c5,c6,c7;
    String formno;

    Signup3(String formno){
        this.formno = formno;
        setTitle("NEW ACCOUNT APPLICATION FORM - PAGE 3");

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("VirtualATM/icons/blogo.jpg"));
        Image i2 = i1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l14 = new JLabel(i3);
        l14.setBounds(150, 20, 100, 100);
        add(l14);

        l1 = new JLabel("Page 3: Account Details");
        l1.setFont(new Font("Raleway", Font.BOLD, 22));

        l2 = new JLabel("Account Type:");
        l3 = new JLabel("Card Number:");
        l4 = new JLabel("XXXX-XXXX-XXXX-4184"); 
        l5 = new JLabel("(Your 16-digit Card number)");
        l6 = new JLabel("It would appear on ATM Card/Cheque Book and Statements");
        l7 = new JLabel("PIN:");
        l8 = new JLabel("XXXX");  // Placeholder
        l9 = new JLabel("(4-digit password)");
        l10 = new JLabel("Services Required:");
        l11 = new JLabel("Form No:");
        l12 = new JLabel(formno);  // Display form number
        
        // Font
        for (JLabel label : new JLabel[]{l2, l3, l5, l6, l7, l9, l10}) {
            label.setFont(new Font("Raleway", Font.BOLD, 12));
        }
        l2.setFont(new Font("Raleway", Font.BOLD, 18));
        l3.setFont(new Font("Raleway", Font.BOLD, 18));
        l4.setFont(new Font("Raleway", Font.BOLD, 18));
        l7.setFont(new Font("Raleway", Font.BOLD, 18));
        l8.setFont(new Font("Raleway", Font.BOLD, 18));
        l10.setFont(new Font("Raleway", Font.BOLD, 18));
        l11.setFont(new Font("Raleway", Font.BOLD, 14));
        l12.setFont(new Font("Raleway", Font.BOLD, 14));

        b1 = new JButton("Submit");
        b1.setFont(new Font("Raleway", Font.BOLD, 14));
        b1.setBackground(Color.BLUE);
        b1.setForeground(Color.BLUE);

        b2 = new JButton("Cancel");
        b2.setFont(new Font("Raleway", Font.BOLD, 14));
        b2.setBackground(Color.RED);
        b2.setForeground(Color.RED);
        // DUMMY services checkboxes
        c1 = new JCheckBox("ATM CARD");
        c2 = new JCheckBox("Internet Banking");
        c3 = new JCheckBox("Mobile Banking");
        c4 = new JCheckBox("EMAIL Alerts");
        c5 = new JCheckBox("Cheque Book");
        c6 = new JCheckBox("E-Statement");
        c7 = new JCheckBox("I hereby declare that the details entered above are true to my best ability", true);

        JCheckBox[] checkBoxes = {c1, c2, c3, c4, c5, c6};
        for (JCheckBox box : checkBoxes) {
            box.setBackground(Color.WHITE);
            box.setFont(new Font("Raleway", Font.BOLD, 16));
        }
        c7.setBackground(Color.WHITE);
        c7.setFont(new Font("Raleway", Font.BOLD, 12));
        // buttons for DUMMY account types. there is no difference between chosen options
        r1 = new JRadioButton("Saving Account");
        r2 = new JRadioButton("Fixed Deposit Account");
        r3 = new JRadioButton("Current Account");
        r4 = new JRadioButton("Recurring Deposit Account");

        ButtonGroup groupgender = new ButtonGroup();
        for (JRadioButton rb : new JRadioButton[]{r1, r2, r3, r4}) {
            rb.setFont(new Font("Raleway", Font.BOLD, 16));
            rb.setBackground(Color.WHITE);
            groupgender.add(rb);
        }

        setLayout(null);

        int y = 140;
        add(l11).setBounds(700,10,70,30);
        add(l12).setBounds(770,10,40,30);
        add(l1).setBounds(280,40,400,40);
        add(l2).setBounds(100,y,200,30); y += 40;
        add(r1).setBounds(100,y,150,30);
        add(r2).setBounds(350,y,300,30); y += 40;
        add(r3).setBounds(100,y,250,30);
        add(r4).setBounds(350,y,250,30); y += 80;
        add(l3).setBounds(100,y,200,30);
        add(l4).setBounds(330,y,250,30); y += 30;
        add(l5).setBounds(100,y,200,20);
        add(l6).setBounds(330,y,500,20); y += 40;
        add(l7).setBounds(100,y,200,30);
        add(l8).setBounds(330,y,200,30); y += 30;
        add(l9).setBounds(100,y,200,20); y += 50;
        add(l10).setBounds(100,y,200,30); y += 50;

        add(c1).setBounds(100,y,200,30);
        add(c2).setBounds(350,y,200,30); y += 50;
        add(c3).setBounds(100,y,200,30);
        add(c4).setBounds(350,y,200,30); y += 50;
        add(c5).setBounds(100,y,200,30);
        add(c6).setBounds(350,y,200,30); y += 80;
        add(c7).setBounds(100,y,600,20); y += 40;
        add(b1).setBounds(250,y,100,30);
        add(b2).setBounds(420,y,100,30);

        getContentPane().setBackground(new Color(241-255-110));
        setSize(850,850);
        setLocation(500,120);
        setVisible(true);

        b1.addActionListener(this);
        b2.addActionListener(this);
    }

    public void actionPerformed(ActionEvent ae){
        String atype = null;
        if(r1.isSelected()){ atype = "Saving Account"; }
        else if(r2.isSelected()){ atype = "Fixed Deposit Account"; }
        else if(r3.isSelected()){ atype = "Current Account"; }
        else if(r4.isSelected()){ atype = "Recurring Deposit Account"; }

        // Generates a random card and pin number
        Random ran = new Random();
        long first7 = (ran.nextLong() % 90000000L) + 5040936000000000L;
        String cardno = "" + Math.abs(first7);
        long first3 = (ran.nextLong() % 9000L) + 1000L;
        String pin = "" + Math.abs(first3);

        String facility = "";
        if(c1.isSelected()){ facility += " ATM Card"; }
        if(c2.isSelected()){ facility += " Internet Banking"; }
        if(c3.isSelected()){ facility += " Mobile Banking"; }
        if(c4.isSelected()){ facility += " EMAIL Alerts"; }
        if(c5.isSelected()){ facility += " Cheque Book"; }
        if(c6.isSelected()){ facility += " E-Statement"; }

        try{
            if(ae.getSource()==b1){
                if(atype == null || atype.equals("")){
                    JOptionPane.showMessageDialog(null, "Fill all the required fields");
                } else {
                    DBConnection c1 = new DBConnection(); // inserts into singup3 table
                    String q1 = "insert into signup3 values('"+formno+"','"+atype+"','"+cardno+"','"+pin+"','"+facility+"')";
                    String q2 = "insert into login (formno, cardno, pin) values('"+formno+"','"+cardno+"','"+pin+"')";
                    String q3 = "insert into users (card_number, pin, name, dob, gender, email) values (?, ?, ?, ?, ?, ?)";

                    c1.s.executeUpdate(q1);
                    c1.s.executeUpdate(q2);

                    PreparedStatement pst = c1.c.prepareStatement(q3);
                    pst.setString(1, cardno);
                    pst.setString(2, pin);
                    pst.setString(3, "New User");
                    pst.setDate(4, java.sql.Date.valueOf("2005-06-02"));
                    pst.setString(5, "Other");
                    pst.setString(6, "default@example.com");
                    pst.executeUpdate();

                    JOptionPane.showMessageDialog(null, "Card Number: " + cardno + "\n Pin:"+ pin);
                    new Deposit(pin).setVisible(true); // goes to deposit page immediately because that should be the first action for every user. 
                    setVisible(false);
                }
            } else if(ae.getSource()==b2){ // cancel button to close app
                System.exit(0);
            }
        } catch(Exception ex){
            ex.printStackTrace();
        }
    }

    public static void main(String[] args){
        new Signup3("").setVisible(true);
    }
}
