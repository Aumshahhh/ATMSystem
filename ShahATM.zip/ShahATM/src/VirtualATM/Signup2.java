package VirtualATM;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class Signup2 extends JFrame implements ActionListener {

    JLabel l1, l2, l3, l4, l5, l6, l7, l8, l9, l10, l11, l12, l13;
    JButton b;
    JRadioButton r1, r2, r3, r4;
    JTextField t1, t2;
    JComboBox c1, c2, c3, c4, c5;
    String formno;

    Signup2(String formno) {
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("VirtualATM/icons/blogo.jpg"));
        Image i2 = i1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l14 = new JLabel(i3);
        l14.setBounds(150, 20, 100, 100);
        add(l14);

        this.formno = formno;
        setTitle("NEW ACCOUNT APPLICATION FORM - PAGE 2");
        
        l1 = new JLabel("Page 2: Additonal Details");
        l2 = new JLabel("Ethnicity:");
        l3 = new JLabel("Category:");
        l4 = new JLabel("Income:");
        l5 = new JLabel("Educational");
        l6 = new JLabel("Occupation:");
        l7 = new JLabel("SSN:");
        l8 = new JLabel("License Number:");
        l9 = new JLabel("Senior Citizen:");
        l10 = new JLabel("Existing Account:");
        l11 = new JLabel("Qualification:");
        l12 = new JLabel("Form No:");
        l13 = new JLabel(formno);
        
         // Set label fonts
        for (JLabel label : new JLabel[]{l1, l2, l3, l4, l5, l6, l7, l8, l9, l10, l11}) {
            label.setFont(new Font("Raleway", Font.BOLD, 18));
        }

        b = new JButton("Next");
        b.setFont(new Font("Raleway", Font.BOLD, 14));
        b.setBackground(Color.BLACK);
        b.setForeground(Color.BLACK);

        t1 = new JTextField();
        t1.setFont(new Font("Raleway", Font.BOLD, 14));

        t2 = new JTextField();
        t2.setFont(new Font("Raleway", Font.BOLD, 14));

        r1 = new JRadioButton("Yes");
        r1.setFont(new Font("Raleway", Font.BOLD, 14));
        r1.setBackground(Color.WHITE);

        r2 = new JRadioButton("No");
        r2.setFont(new Font("Raleway", Font.BOLD, 14));
        r2.setBackground(Color.WHITE);

        r3 = new JRadioButton("Yes");
        r3.setFont(new Font("Raleway", Font.BOLD, 14));
        r3.setBackground(Color.WHITE);

        r4 = new JRadioButton("No");
        r4.setFont(new Font("Raleway", Font.BOLD, 14));
        r4.setBackground(Color.WHITE);

        String religion[] = {"Caucasian", "Hispanic", "African American", "Asian", "American Indian", "Other"};
        c1 = new JComboBox(religion);
        c1.setBackground(Color.WHITE);
        c1.setFont(new Font("Raleway", Font.BOLD, 14));

        String category[] = {"General", "Student", "Business", "Premium", "Other"};
        c2 = new JComboBox(category);
        c2.setBackground(Color.WHITE);
        c2.setFont(new Font("Raleway", Font.BOLD, 14));

        String income[] = {"Null", "<100,000", "<250,000", "<500,000", "Upto 1,000,000", "Above 10,000,00"};
        c3 = new JComboBox(income);
        c3.setBackground(Color.WHITE);
        c3.setFont(new Font("Raleway", Font.BOLD, 14));

        String education[] = {"Non-Graduate", "Graduate", "Post-Graduate", "Doctrate", "Others"};
        c4 = new JComboBox(education);
        c4.setBackground(Color.WHITE);
        c4.setFont(new Font("Raleway", Font.BOLD, 14));

        String occupation[] = {"Salaried", "Self-Employmed", "Business", "Student", "Retired", "Others"};
        c5 = new JComboBox(occupation);
        c5.setBackground(Color.WHITE);
        c5.setFont(new Font("Raleway", Font.BOLD, 14));

        setLayout(null);

        l12.setBounds(700, 10, 60, 30);
        add(l12);

        l13.setBounds(760, 10, 60, 30);
        add(l13);

        l1.setBounds(280, 30, 600, 40);
        add(l1);

        l2.setBounds(100, 120, 100, 30);
        add(l2);

        c1.setBounds(350, 120, 320, 30);
        add(c1);

        l3.setBounds(100, 170, 100, 30);
        add(l3);

        c2.setBounds(350, 170, 320, 30);
        add(c2);

        l4.setBounds(100, 220, 100, 30);
        add(l4);

        c3.setBounds(350, 220, 320, 30);
        add(c3);

        l5.setBounds(100, 270, 150, 30);
        add(l5);

        c4.setBounds(350, 270, 320, 30);
        add(c4);

        l11.setBounds(100, 290, 150, 30);
        add(l11);

        l6.setBounds(100, 340, 150, 30);
        add(l6);

        c5.setBounds(350, 340, 320, 30);
        add(c5);

        l7.setBounds(100, 390, 150, 30);
        add(l7);

        t1.setBounds(350, 390, 320, 30);
        add(t1);

        l8.setBounds(100, 440, 180, 30);
        add(l8);

        t2.setBounds(350, 440, 320, 30);
        add(t2);

        l9.setBounds(100, 490, 150, 30);
        add(l9);

        r1.setBounds(350, 490, 100, 30);
        add(r1);

        r2.setBounds(460, 490, 100, 30);
        add(r2);

        l10.setBounds(100, 540, 180, 30);
        add(l10);

        r3.setBounds(350, 540, 100, 30);
        add(r3);

        r4.setBounds(460, 540, 100, 30);
        add(r4);

        b.setBounds(570, 640, 100, 30);
        add(b);

        b.addActionListener(this);

        getContentPane().setBackground(new Color(241-255-110));
        setSize(850, 750);
        setLocation(500, 120);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        String religion = (String) c1.getSelectedItem();
        String category = (String) c2.getSelectedItem();
        String income = (String) c3.getSelectedItem();
        String education = (String) c4.getSelectedItem();
        String occupation = (String) c5.getSelectedItem();

        String ssn = t1.getText();
        
        if (!ssn.matches("\\d{1,10}")) { // this throws a message saying the ssn should be less than 10 digits.
    JOptionPane.showMessageDialog(null, "SSN must be numeric and up to 10 digits.");
    return;
}
        String license = t2.getText();

        String scitizen = r1.isSelected() ? "Yes" : r2.isSelected() ? "No" : "";
        String eaccount = r3.isSelected() ? "Yes" : r4.isSelected() ? "No" : "";

        try {
            if (license.equals("")) {
                JOptionPane.showMessageDialog(null, "Fill all the required fields");
            } else {
                DBConnection conn = new DBConnection(); // this inserts all the info into the user_details table
                String query = "INSERT INTO user_details (formno, religion, category, income, education, occupation, ssn, license_number, senior_citizen, existing_account) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement pstmt = conn.c.prepareStatement(query);
                pstmt.setString(1, formno);
                pstmt.setString(2, religion);
                pstmt.setString(3, category);
                pstmt.setString(4, income);
                pstmt.setString(5, education);
                pstmt.setString(6, occupation);
                pstmt.setString(7, ssn);
                pstmt.setString(8, license);
                pstmt.setString(9, scitizen);
                pstmt.setString(10, eaccount);

                pstmt.executeUpdate();

                new Signup3(formno).setVisible(true);// go to next page
                setVisible(false);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new Signup2("").setVisible(true);
    }
}
