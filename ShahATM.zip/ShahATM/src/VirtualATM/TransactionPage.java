package VirtualATM;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class TransactionPage extends JFrame implements ActionListener {

    JLabel l1;
    JButton b1, b2, b3, b4, b5, b6, b7;
    String pin;

    TransactionPage(String pin) {
        this.pin = pin;

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("VirtualATM/icons/atm.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1000, 1180, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l2 = new JLabel(i3);
        l2.setBounds(0, 0, 960, 1080);
        add(l2);

        l1 = new JLabel("Please Select Your Transaction");
        l1.setForeground(Color.WHITE);
        l1.setFont(new Font("System", Font.BOLD, 16));

        b1 = new JButton("DEPOSIT");
        b2 = new JButton("CASH WITHDRAWAL");
        b3 = new JButton("QUICK CASH");
        b4 = new JButton("BANK STATEMENT");
        b5 = new JButton("CHANGE PIN");
        b6 = new JButton("CHECK BALANCE");
        b7 = new JButton("EXIT");
        

        setLayout(null);

        l1.setBounds(235, 400, 700, 35);
        l2.add(l1);

        b1.setBounds(170, 499, 150, 35); // deposit
        l2.add(b1);

        b2.setBounds(390, 499, 150, 35); // witjdraw
        l2.add(b2);

        b3.setBounds(170, 543, 150, 35);// QuickCash
        l2.add(b3);

        b4.setBounds(390, 543, 150, 35);//Statement
        l2.add(b4);

        b5.setBounds(170, 588, 150, 35);//Pin
        l2.add(b5);

        b6.setBounds(390, 588, 150, 35);//balance
        l2.add(b6);

        b7.setBounds(390, 633, 150, 35);//exit button
        b7.setOpaque(true); // I need this for the background color to show otherwise without it it stayed white. 
        b7.setBackground(Color.RED); // Set red background
        b7.setForeground(Color.WHITE); // Set white text color
        b7.setBorderPainted(false);
        l2.add(b7);

        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        b4.addActionListener(this);
        b5.addActionListener(this);
        b6.addActionListener(this);
        b7.addActionListener(this);

        setSize(960, 1080);
        setLocation(500, 0);
        setUndecorated(true);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == b1) {
            setVisible(false);
            new Deposit(pin).setVisible(true);// opens deposit screen to deposit money
        } else if (ae.getSource() == b2) {
            setVisible(false);
            new Withdrawal(pin).setVisible(true); // opens withdrawal screen to withdraw money
        } else if (ae.getSource() == b3) {
            setVisible(false);
            new QuickCash(pin).setVisible(true); // opens QuickCash screen to quickly withdraw
        } else if (ae.getSource() == b4) {
            new QuickStatement(pin).setVisible(true); // opens QuickStatement to get a bank statement
        } else if (ae.getSource() == b5) {
            setVisible(false);
            new ChangePin(pin).setVisible(true); // opens pin change screen to change pin
        } else if (ae.getSource() == b6) {
            this.setVisible(false);
            new CheckBalance(pin).setVisible(true); // opens check balance page to see your balance
        } else if (ae.getSource() == b7) { // exit button
            System.exit(0);
        }
    }

    public static void main(String[] args) {
        new TransactionPage("").setVisible(true);
    }
}