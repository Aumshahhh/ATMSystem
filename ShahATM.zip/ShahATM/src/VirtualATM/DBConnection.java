package VirtualATM;

import java.sql.*;

// https://www.youtube.com/watch?v=-1DTYAQ25bY This video was extremely helpful in connecting my dtatbase
public class DBConnection {
    public Connection c;
    public Statement s;

    public DBConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            c = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/atm_simulation",
                "root",
                "Scotchandshadow02."
            );
            s = c.createStatement();
            System.out.println("Database connected successfully.");
        } catch (ClassNotFoundException e) {
            System.err.println("⚠️ MySQL JDBC Driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Failed to connect to database.");
            e.printStackTrace();
        }
    }

    // Optional helper if you need just the Connection later
    public Connection getConnection() {
        return c;
    }
}
