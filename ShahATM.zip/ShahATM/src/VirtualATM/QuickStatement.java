package VirtualATM;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.*;
// THIS IS MY UNIQUE FEATURE
public class QuickStatement extends JFrame {
    JTextArea textArea;
    JButton backBtn;
    JLabel titleLabel;
    String pin;

    QuickStatement(String pin) {
        this.pin = pin;
        setTitle("Bank Statement");

        titleLabel = new JLabel("Bank Of America", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Raleway", Font.BOLD, 20));
        titleLabel.setBounds(100, 10, 400, 30);
        add(titleLabel);

        textArea = new JTextArea();// shows the recent transactions
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setBounds(50, 50, 500, 300);
        add(scrollPane);

        backBtn = new JButton("BACK");
        backBtn.setBounds(220, 370, 120, 30);
        backBtn.addActionListener(e -> {
            setVisible(false);
            new TransactionPage(pin).setVisible(true);
        });
        add(backBtn);

        setLayout(null);
        setSize(600, 450);
        setLocation(500, 200);
        setVisible(true);
        getContentPane().setBackground(Color.WHITE);

        loadStatement();
    }
    // this displays the last transactions for a certain account from the DB
    void loadStatement() {
        try {
            DBConnection c1 = new DBConnection();
            String cardQuery = "SELECT cardno FROM login WHERE pin = ?"; // this gets the user's card number using the pin
            PreparedStatement cardStmt = c1.c.prepareStatement(cardQuery);
            cardStmt.setString(1, pin);
            ResultSet rs = cardStmt.executeQuery();

            if (rs.next()) {
                String cardNumber = rs.getString("cardno");
                // shows card number
                textArea.setText("Card Number: " + cardNumber + "\n");
                textArea.append("\nDate                Type        Amount\n");
                textArea.append("----------------------------------------\n");
                // Gets the last 10 transactions for that card number
                String txnQuery = "SELECT date, type, amount FROM transactions WHERE card_number = ? ORDER BY date DESC LIMIT 10";
                PreparedStatement txnStmt = c1.c.prepareStatement(txnQuery);
                txnStmt.setString(1, cardNumber);
                ResultSet txnRs = txnStmt.executeQuery();

                while (txnRs.next()) {
                    String date = txnRs.getString("date");
                    String type = txnRs.getString("type");
                    double amt = txnRs.getDouble("amount");
                    textArea.append(String.format("%-20s %-10s $%.2f\n", date, type, amt));
                }

            } else {
                textArea.setText("Card number not found for this PIN.");
            }

        } catch (Exception e) {
            textArea.setText("Error loading statement: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new QuickStatement("").setVisible(true);
    }
}
