package VirtualATM;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class ChangePin extends JFrame implements ActionListener {
    JPasswordField pinField1, pinField2;
    JButton changeButton, backButton;
    String pin;

    ChangePin(String pin) {
        this.pin = pin;

        ImageIcon icon = new ImageIcon(ClassLoader.getSystemResource("VirtualATM/icons/atm.jpg"));
        Image scaled = icon.getImage().getScaledInstance(1000, 1180, Image.SCALE_DEFAULT);
        ImageIcon scaledIcon = new ImageIcon(scaled);
        JLabel background = new JLabel(scaledIcon);
        background.setBounds(0, 0, 960, 1080);
        add(background);
        // Label and input field for new pin
        JLabel label1 = new JLabel("Enter A New PIN:");
        label1.setForeground(Color.WHITE);
        label1.setFont(new Font("System", Font.BOLD, 16));
        label1.setBounds(190, 350, 200, 30);
        background.add(label1);

        pinField1 = new JPasswordField();
        pinField1.setBounds(390, 350, 180, 30);
        background.add(pinField1);
        // Label and input field to confirm new pin
        JLabel label2 = new JLabel("Re-Enter New PIN:");
        label2.setForeground(Color.WHITE);
        label2.setFont(new Font("System", Font.BOLD, 16));
        label2.setBounds(190, 400, 200, 30);
        background.add(label2);

        pinField2 = new JPasswordField();
        pinField2.setBounds(390, 400, 180, 30);
        background.add(pinField2);
        // confirm pin change
        changeButton = new JButton("CHANGE");
        changeButton.setBounds(390, 480, 150, 35);
        background.add(changeButton);
        // go back to transactions
        backButton = new JButton("BACK");
        backButton.setBounds(390, 530, 150, 35);
        background.add(backButton);

        changeButton.addActionListener(this);
        backButton.addActionListener(this);

        setLayout(null);
        setSize(960, 1080);
        setUndecorated(true);
        setLocation(500, 0);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        try {
            // gets pin from password fields
            String newPin = new String(pinField1.getPassword());
            String rePin = new String(pinField2.getPassword());

            if (ae.getSource() == backButton) {
                setVisible(false);
                new TransactionPage(pin).setVisible(true);
            } else {
                if (!newPin.equals(rePin)) { // this checks to make sure both pins that were entered match which is very important
                    JOptionPane.showMessageDialog(null, "Entered PINs do not match");
                    return;
                }

                if (newPin.length() != 4 || !newPin.matches("\\d+")) { // mkaes sure pin only has 4 digits
                    JOptionPane.showMessageDialog(null, "PIN must be exactly 4 digits");
                    return;
                }
                // update pin in the datbase as well in the login and users tables
                DBConnection c1 = new DBConnection();
                String updateLogin = "UPDATE login SET pin = ? WHERE pin = ?";
                String updateUsers = "UPDATE users SET pin = ? WHERE pin = ?";

                PreparedStatement ps1 = c1.c.prepareStatement(updateLogin);
                ps1.setString(1, newPin);
                ps1.setString(2, pin);
                ps1.executeUpdate();

                PreparedStatement ps2 = c1.c.prepareStatement(updateUsers);
                ps2.setString(1, newPin);
                ps2.setString(2, pin);
                ps2.executeUpdate();

                JOptionPane.showMessageDialog(null, "PIN changed successfully");
                setVisible(false);
                new TransactionPage(newPin).setVisible(true);
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error updating PIN: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        new ChangePin("").setVisible(true);
    }
}
