package VirtualATM;

import java.util.Date;
import java.text.NumberFormat;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.*;

public class QuickCash extends JFrame implements ActionListener {
    JButton b1, b2, b3, b4, b5, b6, b7;
    String pin;

    QuickCash(String pin) {
        this.pin = pin;

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("VirtualATM/icons/atm.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1000, 1180, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l1 = new JLabel(i3);
        l1.setBounds(0, 0, 960, 1080);
        add(l1);
        // withdrawal label
        JLabel label = new JLabel("SELECT WITHDRAWAL AMOUNT");
        label.setBounds(235, 280, 700, 35);
        label.setForeground(Color.WHITE);
        label.setFont(new Font("System", Font.BOLD, 16));
        l1.add(label);
        // buttons for different amounts
        b1 = new JButton("$20");
        b2 = new JButton("$50");
        b3 = new JButton("$100");
        b4 = new JButton("$200");
        b5 = new JButton("$500");
        b6 = new JButton("$1000");
        b7 = new JButton("BACK");

        JButton[] buttons = {b1, b2, b3, b4, b5, b6, b7};
        int y = 415;
        for (int i = 0; i < 6; i += 2) {
            buttons[i].setBounds(170, y, 150, 35);
            buttons[i + 1].setBounds(390, y, 150, 35);
            l1.add(buttons[i]);
            l1.add(buttons[i + 1]);
            y += 60;
        }
        b7.setBounds(390, y, 150, 35);// back button
        l1.add(b7);

        for (JButton btn : buttons) btn.addActionListener(this);

        setLayout(null);
        setSize(960, 1080);
        setLocation(500, 0);
        setUndecorated(true);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        try {
            String buttonText = ((JButton) ae.getSource()).getText();

            if (buttonText.equals("BACK")) {
                setVisible(false);
                new TransactionPage(pin).setVisible(true);
                return;
            }

            String amountStr = buttonText.substring(1); 
            double amount = Double.parseDouble(amountStr);
            Date date = new Date();
            // currency fomat
            NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(Locale.US); //got it from:https://www.geeksforgeeks.org/numberformat-getcurrencyinstance-method-in-java-with-examples/

            DBConnection conn = new DBConnection();
            String cardQuery = "SELECT cardno FROM login WHERE pin = ?"; // get the card number using pin
            PreparedStatement cardStmt = conn.c.prepareStatement(cardQuery);
            cardStmt.setString(1, pin);
            ResultSet rs = cardStmt.executeQuery();

            if (rs.next()) {
                String cardNumber = rs.getString("cardno");
                // make sure user has sufficient balance to withdraw
                String balanceQuery = "SELECT SUM(CASE WHEN type = 'Deposit' THEN amount ELSE -amount END) AS balance FROM transactions WHERE card_number = ?";
                PreparedStatement balanceStmt = conn.c.prepareStatement(balanceQuery);
                balanceStmt.setString(1, cardNumber);
                ResultSet balanceRs = balanceStmt.executeQuery();

                if (balanceRs.next()) {
                    double balance = balanceRs.getDouble("balance");
                    if (amount > balance) {
                        JOptionPane.showMessageDialog(null, "Insufficient balance.");
                        return;
                    }
                }
                // update withdrawal in transactions database
                String insertQuery = "INSERT INTO transactions (card_number, date, type, amount) VALUES (?, ?, ?, ?)";
                PreparedStatement pstmt = conn.c.prepareStatement(insertQuery);
                pstmt.setString(1, cardNumber);
                pstmt.setTimestamp(2, new java.sql.Timestamp(date.getTime()));
                pstmt.setString(3, "Withdrawal");
                pstmt.setDouble(4, amount);
                pstmt.executeUpdate();

                JOptionPane.showMessageDialog(null, currencyFormat.format(amount) + " withdrawn successfully.");
                setVisible(false);
                new TransactionPage(pin).setVisible(true);
            } else {
                JOptionPane.showMessageDialog(null, "Card number not found for this account.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Transaction failed: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        new QuickCash("").setVisible(true);
    }
}